<?php
/**
 *                       ######
 *                       ######
 * ############    ####( ######  #####. ######  ############   ############
 * #############  #####( ######  #####. ######  #############  #############
 *        ######  #####( ######  #####. ######  #####  ######  #####  ######
 * ###### ######  #####( ######  #####. ######  #####  #####   #####  ######
 * ###### ######  #####( ######  #####. ######  #####          #####  ######
 * #############  #############  #############  #############  #####  ######
 *  ############   ############  #############   ############  #####  ######
 *                                      ######
 *                               #############
 *                               ############
 *
 * Adyen PrestaShop plugin
 *
 * @author Adyen BV <support@adyen.com>
 * @copyright (c) 2021 Adyen B.V.
 * @license https://opensource.org/licenses/MIT MIT license
 * This file is open source and available under the MIT license.
 * See the LICENSE file for more info.
 */

namespace Adyen\PrestaShop\service\adapter\classes;

class CustomerThreadAdapter
{
    /**
     * Returns Customer thread instance by customer email address and order id
     *
     * @param $email
     * @param $orderId
     *
     * @return \CustomerThread
     */
    public function getCustomerThreadByEmailAndOrderId($email, $orderId)
    {
        return new \CustomerThread(\CustomerThread::getIdCustomerThreadByEmailAndIdOrder($email, $orderId));
    }
}
